Drop pictures here to replace the WebOS app icons.

Name each picture after the app:
  browser.png      -> Browser
  optimizer.png    -> Optimizer
  games.png        -> Game Launcher
  settings.png     -> Settings

Works with .png .jpg .jpeg .webp .gif .svg .ico .bmp (square pictures look best).
Switch back to WebOS and the new icons appear automatically.
Delete a picture to get the default icon back.
