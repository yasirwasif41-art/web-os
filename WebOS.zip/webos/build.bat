@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 (
  echo Install failed. Check your internet connection and try again.
  pause
  exit /b 1
)
call npm run build
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
xcopy /E /I /Y icons dist\WebOS-win32-x64\icons >nul
echo.
echo Done! Open the dist\WebOS-win32-x64 folder and run WebOS.exe
echo Put your own app pictures in dist\WebOS-win32-x64\icons (see README.txt in there).
pause
