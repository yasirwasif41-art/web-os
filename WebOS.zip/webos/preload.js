const { contextBridge, ipcRenderer } = require('electron');

const call = (channel) => (...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld('api', {
  stats: call('sys:stats'),
  sysInfo: call('sys:info'),
  processes: call('sys:processes'),
  kill: call('sys:kill'),
  cleanScan: call('clean:scan'),
  cleanRun: call('clean:run'),
  highPerf: call('power:highperf'),
  flushDns: call('dns:flush'),
  defaultRoots: call('games:defaultRoots'),
  scanGames: call('games:scan'),
  launch: call('games:launch'),
  reveal: call('games:reveal'),
  pickFolder: call('games:pickFolder'),
  pickExe: call('games:pickExe'),
  pickWallpaper: call('wallpaper:pick'),
  clearBrowsingData: call('browser:clearData'),
  toggleFullscreen: call('window:fullscreen'),
  quit: call('app:quit'),
  findCover: call('covers:find'),
  pickCover: call('covers:pick'),
  exeIcon: call('games:exeIcon'),
  icons: call('icons:list'),
  openIconsFolder: call('icons:open'),
  onOpenUrl: (cb) => ipcRenderer.on('open-url', (_e, url) => cb(url)),
  onBrowserKey: (cb) => ipcRenderer.on('browser-key', (_e, k) => cb(k))
});
