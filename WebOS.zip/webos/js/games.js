// Game Launcher: finds .exe files / games on your PC, shows cover art found online, and launches them.
(function () {
  const { el, esc } = OS;

  const basename = (p) => String(p).split(/[\\/]/).pop();
  const hue = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  const letter = (s) => ((String(s).match(/[a-z0-9]/i) || ['?'])[0]).toUpperCase();
  const WEEK = 7 * 24 * 3600 * 1000;

  const load = () => Object.assign(
    { items: [], roots: [], favs: {}, hidden: {}, played: {}, covers: {}, coverMiss: {}, scanned: false, includeApps: false, autoCovers: true },
    Store.get('games', {})
  );

  const iconCache = new Map(); // exe path -> data URL ('' = none)

  OS.register({
    id: 'games', title: 'Game Launcher', icon: '🎮', width: 980, height: 640, single: true,
    create(w) {
      const api = window.api;
      const b = w.body;
      b.classList.add('gm');
      b.innerHTML =
        '<div class="gm-bar">' +
        '<input class="gm-search" type="text" placeholder="Search games & programs…" spellcheck="false">' +
        '<div class="seg"><button data-f="all" class="on">All</button><button data-f="fav">★ Favorites</button><button data-f="recent">Recent</button><button data-f="hidden">Hidden</button></div>' +
        '<button class="btn pri" data-a="scan">⟳ Scan PC</button>' +
        '<button class="btn" data-a="covers" title="Look up cover art for your games online">🖼 Find covers</button>' +
        '<button class="btn" data-a="addfolder">＋ Folder</button>' +
        '<button class="btn" data-a="addexe">＋ .exe</button></div>' +
        '<div class="gm-info"><span class="gm-status"></span>' +
        '<label class="chk" style="margin:0"><input type="checkbox" class="gm-pf"> Include Program Files (all installed programs)</label>' +
        '<label class="chk" style="margin:0" title="Sends game names to the Steam store search to find their cover art"><input type="checkbox" class="gm-auto"> Find cover art online automatically</label></div>' +
        '<div class="gm-grid"></div>';

      const search = b.querySelector('.gm-search');
      const grid = b.querySelector('.gm-grid');
      const statusEl = b.querySelector('.gm-status');
      const pf = b.querySelector('.gm-pf');
      const auto = b.querySelector('.gm-auto');
      const scanBtn = b.querySelector('[data-a=scan]');
      const coverBtn = b.querySelector('[data-a=covers]');

      let data = load();
      let filter = 'all';
      let scanning = false;
      let finding = false;
      let coverMsg = '';
      let dead = false;
      let io = null;
      const cards = new Map(); // item id -> card element
      const save = () => Store.set('games', data);

      pf.checked = !!data.includeApps;
      pf.addEventListener('change', () => { data.includeApps = pf.checked; save(); });
      auto.checked = data.autoCovers !== false;
      auto.addEventListener('change', () => { data.autoCovers = auto.checked; save(); });

      const itemById = (id) => data.items.find((i) => i.id === id);

      function updateStatus() {
        const base = scanning
          ? 'Scanning your folders… this can take a minute.'
          : data.items.length ? `${data.items.length} found` : '';
        statusEl.textContent = base + (coverMsg ? (base ? '  ·  ' : '') + coverMsg : '');
      }

      async function play(it, exe) {
        const r = await api.launch(exe);
        if (r.ok) {
          data.played[it.id] = Date.now();
          save();
          OS.toast(`Launching ${it.name}…`);
        } else {
          OS.toast(`Couldn’t launch ${it.name}: ${r.error}`);
        }
      }

      // ---------- card art ----------
      function fillArt(art, it) {
        art.innerHTML = '';
        const cv = data.covers[it.id];
        if (cv && cv.url) {
          const img = new Image();
          img.className = 'cv';
          img.alt = '';
          img.draggable = false;
          img.onerror = () => { delete data.covers[it.id]; save(); fillArt(art, it); }; // file was deleted
          img.src = cv.url;
          art.classList.add('has');
          art.style.background = '#000';
          art.appendChild(img);
          return;
        }
        art.classList.remove('has');
        const h = hue(it.name);
        art.style.background = `linear-gradient(135deg, hsl(${h} 55% 32%), hsl(${(h + 40) % 360} 60% 20%))`;
        const cached = iconCache.get(it.exe);
        if (cached) art.innerHTML = `<img class="xi" src="${cached}" alt="" draggable="false">`;
        else art.innerHTML = `<span class="lt">${esc(letter(it.name))}</span>`;
      }

      function loadExeIcon(card, it) {
        const cached = iconCache.get(it.exe);
        if (cached !== undefined) return;
        iconCache.set(it.exe, ''); // mark as requested
        api.exeIcon(it.exe).then((url) => {
          if (dead || !url) return;
          iconCache.set(it.exe, url);
          const cur = cards.get(it.id);
          if (cur && cur.isConnected && !data.covers[it.id]) fillArt(cur.querySelector('.gart'), it);
        }).catch(() => {});
      }

      function setupObserver() {
        if (io) io.disconnect();
        io = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            io.unobserve(en.target);
            const it = itemById(en.target.dataset.id);
            if (it && !data.covers[it.id]) loadExeIcon(en.target, it);
          }
        }, { root: grid, rootMargin: '300px' });
      }

      // ---------- cover art lookup ----------
      async function findCovers(items, opts = {}) {
        const { force = false, auto: isAuto = false } = opts;
        if (finding) { if (!isAuto) OS.toast('Already looking for cover art…'); return; }
        const now = Date.now();
        const todo = items.filter((it) => force || (!data.covers[it.id] && (!isAuto || !data.coverMiss[it.id] || now - data.coverMiss[it.id] > WEEK)));
        if (!todo.length) { if (!isAuto) OS.toast('Every game already has cover art (or none was found).'); return; }

        finding = true;
        coverBtn.disabled = true;
        const total = todo.length;
        let done = 0;
        let found = 0;
        let netFail = false;
        const queue = todo.slice();

        async function worker() {
          while (queue.length && !netFail && !dead) {
            const it = queue.shift();
            let r;
            try { r = await api.findCover({ id: it.id, name: it.name, dir: it.dir }); } catch { r = { ok: false, reason: 'nomatch' }; }
            done++;
            if (r.ok) {
              found++;
              data.covers[it.id] = { url: r.url, title: r.title };
              delete data.coverMiss[it.id];
              const card = cards.get(it.id);
              if (card && card.isConnected) fillArt(card.querySelector('.gart'), it);
            } else if (r.reason === 'network') {
              netFail = true;
            } else {
              data.coverMiss[it.id] = Date.now();
            }
            coverMsg = `Finding cover art… ${done}/${total}`;
            updateStatus();
          }
        }
        await Promise.all([worker(), worker(), worker()]);

        finding = false;
        coverBtn.disabled = false;
        if (!dead) {
          save();
          coverMsg = '';
          updateStatus();
          if (netFail) OS.toast('Couldn’t reach the internet — showing each program’s own icon instead.');
          else if (!isAuto || found) OS.toast(found ? `Found cover art for ${found} of ${total}` : `No cover art found for ${total === 1 ? 'that game' : 'those games'}`);
        }
      }

      // ---------- menu ----------
      function menu(it, x, y) {
        const items = [{ label: '▶  Launch', fn: () => play(it, it.exe) }];
        (it.alts || []).slice(0, 8).forEach((a) => items.push({ label: '▶  ' + basename(a), fn: () => play(it, a) }));
        items.push(
          { sep: true },
          { label: '🖼  Find cover art online', fn: () => findCovers([it], { force: true }) },
          {
            label: '📁  Choose cover image…',
            fn: async () => {
              const r = await api.pickCover(it.id);
              if (r && r.ok) {
                data.covers[it.id] = { url: r.url, title: 'Custom' };
                save();
                const c = cards.get(it.id);
                if (c) fillArt(c.querySelector('.gart'), it);
              } else if (r && r.error) OS.toast('Couldn’t use that image: ' + r.error);
            }
          }
        );
        if (data.covers[it.id]) {
          items.push({
            label: '✖  Remove cover',
            fn: () => {
              delete data.covers[it.id];
              data.coverMiss[it.id] = Date.now(); // don't re-download it automatically
              save();
              const c = cards.get(it.id);
              if (c) { fillArt(c.querySelector('.gart'), it); loadExeIcon(c, it); }
            }
          });
        }
        items.push(
          { sep: true },
          { label: '📂  Open folder', fn: () => api.reveal(it.exe) },
          { label: data.hidden[it.id] ? '👁  Unhide' : '🙈  Hide', fn: () => { if (data.hidden[it.id]) delete data.hidden[it.id]; else data.hidden[it.id] = true; save(); render(); } }
        );
        if (it.manual) {
          items.push({ label: '🗑  Remove from list', fn: () => { data.items = data.items.filter((i) => i.id !== it.id); save(); render(); } });
        }
        OS.contextMenu(x, y, items);
      }

      // ---------- render ----------
      function render() {
        const q = search.value.trim().toLowerCase();
        let list = data.items.filter((i) => !q || i.name.toLowerCase().includes(q));
        list = filter === 'hidden' ? list.filter((i) => data.hidden[i.id]) : list.filter((i) => !data.hidden[i.id]);
        if (filter === 'fav') list = list.filter((i) => data.favs[i.id]);
        if (filter === 'recent') {
          list = list.filter((i) => data.played[i.id]).sort((a, c) => data.played[c.id] - data.played[a.id]);
        } else {
          list.sort((a, c) => (data.favs[c.id] ? 1 : 0) - (data.favs[a.id] ? 1 : 0) || a.name.localeCompare(c.name));
        }

        updateStatus();
        setupObserver();
        cards.clear();
        grid.innerHTML = '';
        if (!list.length) {
          const msg = scanning ? 'Looking for games and programs…'
            : !data.items.length ? 'Nothing here yet. Press “Scan PC” to look in the usual game folders (Steam, Epic, GOG, C:\\Games…), or add a folder or an .exe yourself.'
            : filter === 'fav' ? 'No favorites yet — press ☆ on a game.'
            : filter === 'recent' ? 'Games you launch will show up here.'
            : filter === 'hidden' ? 'No hidden items.'
            : 'No matches.';
          grid.appendChild(el('div', 'empty', esc(msg)));
          return;
        }

        for (const it of list) {
          const card = el('div', 'gcard',
            '<div class="gart"></div>' +
            `<div class="gname" title="${esc(it.exe)}">${esc(it.name)}</div>` +
            `<div class="gsub">${esc(basename(it.exe))}</div>` +
            `<div class="gact"><button class="btn pri play">▶ Play</button><button class="btn ic fav" title="Favorite">${data.favs[it.id] ? '★' : '☆'}</button><button class="btn ic more" title="More">⋯</button></div>`);
          card.dataset.id = it.id;
          const art = card.querySelector('.gart');
          fillArt(art, it);
          art.addEventListener('dblclick', () => play(it, it.exe));
          card.querySelector('.play').addEventListener('click', () => play(it, it.exe));
          card.querySelector('.fav').addEventListener('click', () => {
            if (data.favs[it.id]) delete data.favs[it.id]; else data.favs[it.id] = true;
            save();
            render();
          });
          card.querySelector('.more').addEventListener('click', (e) => { const r = e.currentTarget.getBoundingClientRect(); menu(it, r.left, r.bottom + 4); });
          card.addEventListener('contextmenu', (e) => { e.preventDefault(); menu(it, e.clientX, e.clientY); });
          cards.set(it.id, card);
          grid.appendChild(card);
          if (!data.covers[it.id]) io.observe(card);
        }
      }

      async function scan() {
        if (scanning) return;
        scanning = true;
        scanBtn.disabled = true;
        render();
        try {
          const dr = await api.defaultRoots();
          const roots = [...new Set([...dr.games, ...data.roots, ...(data.includeApps ? dr.apps : [])])];
          if (!roots.length) {
            OS.toast('No game folders found — use “＋ Folder” to point me at one.');
          } else {
            const found = await api.scanGames(roots);
            const manual = data.items.filter((i) => i.manual && !found.some((f) => f.id === i.id));
            data.items = [...found, ...manual];
            data.scanned = true;
            save();
            OS.toast(`Found ${found.length} item${found.length === 1 ? '' : 's'}`);
          }
        } catch (e) {
          console.error(e);
          OS.toast('Scan failed: ' + e.message);
        } finally {
          scanning = false;
          scanBtn.disabled = false;
          render();
        }
        if (data.autoCovers !== false) findCovers(data.items, { auto: true });
      }

      b.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-a]');
        const f = e.target.closest('[data-f]');
        if (f) {
          filter = f.dataset.f;
          b.querySelectorAll('[data-f]').forEach((x) => x.classList.toggle('on', x === f));
          render();
        } else if (a) {
          if (a.dataset.a === 'scan') scan();
          else if (a.dataset.a === 'covers') {
            if (!data.items.length) OS.toast('Scan your PC for games first.');
            else findCovers(data.items.filter((i) => !data.hidden[i.id]));
          } else if (a.dataset.a === 'addfolder') {
            const p = await api.pickFolder();
            if (p) { if (!data.roots.includes(p)) data.roots.push(p); save(); scan(); }
          } else if (a.dataset.a === 'addexe') {
            const x = await api.pickExe();
            if (x) {
              const id = x.path.toLowerCase();
              if (!data.items.some((i) => i.id === id)) data.items.push({ id, name: x.name, dir: x.dir, exe: x.path, alts: [], size: x.size, manual: true });
              save();
              render();
              OS.toast(`Added ${x.name}`);
              if (data.autoCovers !== false) findCovers(data.items, { auto: true });
            }
          }
        }
      });
      search.addEventListener('input', render);
      w.onClose(() => { dead = true; if (io) io.disconnect(); });

      render();
      if (!data.scanned) scan();
      else if (data.autoCovers !== false) setTimeout(() => { if (!dead) findCovers(data.items, { auto: true }); }, 800);
    }
  });
})();
