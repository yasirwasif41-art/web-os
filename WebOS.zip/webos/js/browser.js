// Browser app: tabs, search engine, saved sites.
(function () {
  const { el, esc } = OS;

  const ENGINES = {
    google: { name: 'Google', url: 'https://www.google.com/search?q=' },
    duckduckgo: { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=' },
    bing: { name: 'Bing', url: 'https://www.bing.com/search?q=' },
    brave: { name: 'Brave Search', url: 'https://search.brave.com/search?q=' },
    youtube: { name: 'YouTube', url: 'https://www.youtube.com/results?search_query=' }
  };
  window.SEARCH_ENGINES = ENGINES;

  const SUGGESTED = [
    { title: 'YouTube', url: 'https://www.youtube.com' },
    { title: 'Wikipedia', url: 'https://www.wikipedia.org' },
    { title: 'Reddit', url: 'https://www.reddit.com' },
    { title: 'GitHub', url: 'https://github.com' },
    { title: 'Twitch', url: 'https://www.twitch.tv' },
    { title: 'Steam', url: 'https://store.steampowered.com' }
  ];

  // Look like a normal Chrome so sites don't treat us as an unsupported browser
  const UA = navigator.userAgent.replace(/\s(Electron|webos)\/\S+/gi, '');

  const engine = () => { const e = Store.get('engine', 'google'); return ENGINES[e] ? e : 'google'; };

  function toUrl(text, eng) {
    const t = String(text || '').trim();
    if (!t) return '';
    if (/^https?:\/\/\S+$/i.test(t)) return t;
    if (/^localhost(:\d+)?([/?#]\S*)?$/i.test(t)) return 'http://' + t;
    if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?([/?#]\S*)?$/.test(t)) return 'http://' + t;
    if (/^[\w-]+(\.[\w-]+)+(:\d+)?([/?#]\S*)?$/.test(t)) return 'https://' + t;
    return ENGINES[eng].url + encodeURIComponent(t);
  }

  const norm = (u) => String(u || '').replace(/\/+$/, '').toLowerCase();
  const getSaved = () => Store.get('saved', []);
  const isSaved = (u) => !!u && getSaved().some((s) => norm(s.url) === norm(u));
  const letter = (s) => ((String(s).match(/[a-z0-9]/i) || ['?'])[0]).toUpperCase();

  class BrowserApp {
    constructor(w, opts) {
      this.w = w;
      this.tabs = [];
      this.cur = null;
      this.seq = 1;

      const b = w.body;
      b.classList.add('br');
      b.tabIndex = -1;
      b.innerHTML =
        '<div class="br-tabs"><div class="br-tablist"></div><button class="br-newtab" title="New tab (Ctrl+T)">＋</button></div>' +
        '<div class="br-bar">' +
        '<button data-a="back" title="Back">◀</button><button data-a="fwd" title="Forward">▶</button>' +
        '<button data-a="reload" title="Reload">⟳</button><button data-a="home" title="Home">⌂</button>' +
        '<input class="br-addr" type="text" spellcheck="false" placeholder="Search or enter address">' +
        '<button data-a="star" title="Save this site">☆</button>' +
        '<select class="br-engine" title="Search engine"></select></div>' +
        '<div class="br-load"></div><div class="br-saved"></div><div class="br-view"></div>';

      this.tablist = b.querySelector('.br-tablist');
      this.view = b.querySelector('.br-view');
      this.addr = b.querySelector('.br-addr');
      this.savedBar = b.querySelector('.br-saved');
      this.loadBar = b.querySelector('.br-load');
      this.backBtn = b.querySelector('[data-a=back]');
      this.fwdBtn = b.querySelector('[data-a=fwd]');
      this.reloadBtn = b.querySelector('[data-a=reload]');
      this.starBtn = b.querySelector('[data-a=star]');
      this.engineSel = b.querySelector('.br-engine');

      for (const [id, e] of Object.entries(ENGINES)) {
        const o = el('option', null, esc(e.name));
        o.value = id;
        this.engineSel.appendChild(o);
      }
      this.engineSel.value = engine();
      this.engineSel.addEventListener('change', () => Store.set('engine', this.engineSel.value));

      b.querySelector('.br-newtab').addEventListener('click', () => this.newTab());
      b.querySelector('.br-bar').addEventListener('click', (e) => {
        const a = e.target.closest('[data-a]');
        if (a) this.action(a.dataset.a);
      });
      this.addr.addEventListener('focus', () => this.addr.select());
      this.addr.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const u = toUrl(this.addr.value, engine());
          if (u && this.cur) { this.navigate(this.cur, u); this.addr.blur(); }
        } else if (e.key === 'Escape') {
          this.addr.blur();
          this.refresh();
        }
      });
      b.addEventListener('keydown', (e) => {
        if (e.altKey && !e.ctrlKey) {
          if (e.key === 'ArrowLeft') { e.preventDefault(); this.key('back'); }
          else if (e.key === 'ArrowRight') { e.preventDefault(); this.key('fwd'); }
          return;
        }
        if (e.key === 'F5') { e.preventDefault(); this.key('r'); return; }
        if (!e.ctrlKey || e.altKey) return;
        const k = e.key.toLowerCase();
        if (['t', 'w', 'l', 'r'].includes(k)) { e.preventDefault(); this.key(k); }
      });

      const offSaved = Store.on('saved', () => { this.renderSaved(); this.tabs.forEach((t) => t.renderTiles()); this.refresh(); });
      const offEngine = Store.on('engine', () => {
        this.engineSel.value = engine();
        this.tabs.forEach((t) => t.updatePlaceholder());
      });
      w.onClose(() => { offSaved(); offEngine(); });

      this.renderSaved();
      this.newTab(opts && opts.url);
    }

    // shortcuts: from the host window, or forwarded from inside a page by the main process
    key(k) {
      if (k === 't') this.newTab();
      else if (k === 'w') { if (this.cur) this.closeTab(this.cur); }
      else if (k === 'l') { this.addr.focus(); }
      else if (k === 'r') this.action('reload');
      else if (k === 'back') this.action('back');
      else if (k === 'fwd') this.action('fwd');
    }

    // ----- tabs -----
    newTab(url) {
      const tab = { id: this.seq++, view: null, ready: false, url: '', title: 'New tab', favicon: '', loading: false };
      tab.el = el('div', 'br-tab', '<span class="ic">🌐</span><span class="tt">New tab</span><button class="x" title="Close tab">✕</button>');
      tab.el.addEventListener('click', (e) => { if (e.target.closest('.x')) this.closeTab(tab); else this.select(tab); });
      tab.el.addEventListener('auxclick', (e) => { if (e.button === 1) this.closeTab(tab); });
      this.tablist.appendChild(tab.el);

      tab.pane = el('div', 'br-pane');
      tab.pane.dataset.mode = 'start';
      tab.start = this.buildStart(tab);
      tab.pane.appendChild(tab.start);
      this.view.appendChild(tab.pane);

      this.tabs.push(tab);
      this.select(tab);
      if (url) this.navigate(tab, toUrl(url, engine()));
      else setTimeout(() => this.addr.focus(), 0);
      return tab;
    }

    select(tab) {
      this.cur = tab;
      for (const t of this.tabs) {
        t.el.classList.toggle('on', t === tab);
        t.pane.classList.toggle('on', t === tab);
      }
      this.refresh();
    }

    closeTab(tab) {
      const i = this.tabs.indexOf(tab);
      if (i < 0) return;
      this.tabs.splice(i, 1);
      tab.el.remove();
      tab.pane.remove(); // also removes the webview
      if (!this.tabs.length) { this.newTab(); return; }
      if (this.cur === tab) this.select(this.tabs[Math.min(i, this.tabs.length - 1)]);
    }

    // ----- start page -----
    buildStart(tab) {
      const s = el('div', 'br-start',
        '<div class="br-logo">🌐</div><h2>Search the web</h2>' +
        '<form class="br-sform"><input type="text" spellcheck="false"><button class="btn pri" type="submit">Search</button></form>' +
        '<div class="br-sub"></div><div class="br-tiles"></div>');
      const input = s.querySelector('input');
      tab.updatePlaceholder = () => { input.placeholder = `Search with ${ENGINES[engine()].name} or type a web address`; };
      tab.updatePlaceholder();
      s.querySelector('form').addEventListener('submit', (e) => {
        e.preventDefault();
        const u = toUrl(input.value, engine());
        if (u) { input.value = ''; this.navigate(tab, u); }
      });
      tab.renderTiles = () => {
        const saved = getSaved();
        const list = saved.length ? saved : SUGGESTED;
        s.querySelector('.br-sub').textContent = saved.length ? 'Your saved sites' : 'Suggested sites (star ☆ any page to save it here)';
        const box = s.querySelector('.br-tiles');
        box.innerHTML = '';
        for (const it of list) {
          const t = el('div', 'tile', `<div class="tl">${esc(letter(it.title))}</div><div class="tn">${esc(it.title)}</div>`);
          t.addEventListener('click', (e) => {
            if (e.target.closest('.x')) return;
            this.navigate(tab, it.url);
          });
          if (saved.length) {
            const x = el('button', 'x', '✕');
            x.title = 'Remove from saved sites';
            x.addEventListener('click', () => Store.set('saved', getSaved().filter((s2) => norm(s2.url) !== norm(it.url))));
            t.appendChild(x);
          }
          box.appendChild(t);
        }
      };
      tab.renderTiles();
      return s;
    }

    // ----- navigation -----
    navigate(tab, url) {
      if (!url) return;
      tab.pane.dataset.mode = 'web';
      this.hideError(tab);
      tab.url = url;
      if (!tab.view) this.makeView(tab, url);
      else if (tab.ready) Promise.resolve(tab.view.loadURL(url)).catch(() => {});
      else tab.view.setAttribute('src', url);
      this.refresh();
    }

    makeView(tab, url) {
      const v = document.createElement('webview');
      v.setAttribute('partition', 'persist:webos-browser');
      v.setAttribute('allowpopups', '');
      v.setAttribute('useragent', UA);
      v.setAttribute('src', url);
      tab.pane.appendChild(v);
      tab.view = v;
      tab.ready = false;

      v.addEventListener('dom-ready', () => { tab.ready = true; this.updateTab(tab); });
      v.addEventListener('did-start-loading', () => { tab.loading = true; this.updateTab(tab); });
      v.addEventListener('did-stop-loading', () => { tab.loading = false; this.updateTab(tab); });
      v.addEventListener('page-title-updated', (e) => { tab.title = e.title || tab.title; this.updateTab(tab); });
      v.addEventListener('page-favicon-updated', (e) => { tab.favicon = (e.favicons && e.favicons[0]) || ''; this.updateTab(tab); });
      v.addEventListener('did-navigate', (e) => {
        if (/^chrome-error:/i.test(e.url)) return;
        tab.url = e.url;
        this.hideError(tab);
        this.updateTab(tab);
      });
      v.addEventListener('did-navigate-in-page', (e) => {
        if (e.isMainFrame) { tab.url = e.url; this.updateTab(tab); }
      });
      v.addEventListener('did-fail-load', (e) => {
        if (e.isMainFrame && e.errorCode !== -3) this.showError(tab, e);
      });
    }

    goHome(tab) {
      if (tab.view) { tab.view.remove(); tab.view = null; tab.ready = false; }
      this.hideError(tab);
      tab.url = '';
      tab.title = 'New tab';
      tab.favicon = '';
      tab.loading = false;
      tab.pane.dataset.mode = 'start';
      this.updateTab(tab);
    }

    showError(tab, e) {
      this.hideError(tab);
      const d = el('div', 'br-err',
        `<div style="font-size:42px">😕</div><h3>Can’t reach this page</h3><p class="muted">${esc(e.errorDescription || 'Unknown error')}<br>${esc(e.validatedURL || '')}</p>`);
      const retry = el('button', 'btn pri', 'Try again');
      retry.addEventListener('click', () => {
        this.hideError(tab);
        if (tab.view && tab.ready) Promise.resolve(tab.view.loadURL(e.validatedURL || tab.url)).catch(() => {});
      });
      d.appendChild(retry);
      tab.errEl = d;
      tab.pane.appendChild(d);
      tab.loading = false;
      this.updateTab(tab);
    }

    hideError(tab) {
      if (tab.errEl) { tab.errEl.remove(); tab.errEl = null; }
    }

    action(a) {
      const t = this.cur;
      if (!t) return;
      const live = t.view && t.ready;
      if (a === 'back' && live && t.view.canGoBack()) t.view.goBack();
      else if (a === 'fwd' && live && t.view.canGoForward()) t.view.goForward();
      else if (a === 'reload' && live) { if (t.loading) t.view.stop(); else t.view.reload(); }
      else if (a === 'home') this.goHome(t);
      else if (a === 'star') this.toggleStar();
    }

    toggleStar() {
      const t = this.cur;
      if (!t || !/^https?:/i.test(t.url)) { OS.toast('Open a website first, then save it.'); return; }
      let list = getSaved();
      if (isSaved(t.url)) {
        list = list.filter((s) => norm(s.url) !== norm(t.url));
        OS.toast('Removed from saved sites');
      } else {
        list.push({ title: t.title && t.title !== 'New tab' ? t.title : t.url, url: t.url, favicon: t.favicon || '' });
        OS.toast('Saved to your sites ★');
      }
      Store.set('saved', list);
    }

    // ----- UI sync -----
    updateTab(tab) {
      tab.el.classList.toggle('ld', tab.loading);
      tab.el.querySelector('.tt').textContent = tab.title || 'New tab';
      tab.el.querySelector('.ic').innerHTML = tab.loading
        ? '<span class="spin"></span>'
        : (tab.favicon ? `<img src="${esc(tab.favicon)}" alt="">` : '🌐');
      if (tab === this.cur) this.refresh();
    }

    refresh() {
      const t = this.cur;
      if (!t) return;
      if (document.activeElement !== this.addr) this.addr.value = /^https?:/i.test(t.url) ? t.url : '';
      const saved = isSaved(t.url);
      this.starBtn.textContent = saved ? '★' : '☆';
      this.starBtn.classList.toggle('on', saved);
      let cb = false;
      let cf = false;
      if (t.view && t.ready) {
        try { cb = t.view.canGoBack(); cf = t.view.canGoForward(); } catch { /* not ready yet */ }
      }
      this.backBtn.disabled = !cb;
      this.fwdBtn.disabled = !cf;
      this.reloadBtn.textContent = t.loading ? '✕' : '⟳';
      this.loadBar.classList.toggle('on', !!t.loading);
      this.w.setTitle((t.title && t.title !== 'New tab' ? t.title + ' – ' : '') + 'Browser');
    }

    renderSaved() {
      const list = getSaved();
      this.savedBar.innerHTML = '';
      if (!list.length) {
        this.savedBar.appendChild(el('span', 'muted', 'Press ☆ in the toolbar to save a site here'));
        return;
      }
      for (const it of list) {
        const c = el('div', 'chip', `<span class="t">${esc(it.title)}</span>`);
        c.title = it.url;
        c.addEventListener('click', (e) => {
          if (e.target.closest('.x')) return;
          if (e.ctrlKey) this.newTab(it.url);
          else if (this.cur) this.navigate(this.cur, it.url);
        });
        c.addEventListener('auxclick', (e) => { if (e.button === 1) this.newTab(it.url); });
        const x = el('button', 'x', '✕');
        x.title = 'Remove';
        x.addEventListener('click', () => Store.set('saved', getSaved().filter((s) => norm(s.url) !== norm(it.url))));
        c.appendChild(x);
        this.savedBar.appendChild(c);
      }
    }
  }

  OS.register({
    id: 'browser', title: 'Browser', icon: '🌐', width: 1020, height: 660,
    create(w, opts) {
      const app = new BrowserApp(w, opts);
      w.api.newTab = (url) => app.newTab(url);
      w.api.key = (k) => app.key(k);
    }
  });
})();
