// Built-in wallpapers are pure CSS (no image files, so they cost almost nothing to draw).
window.WALLPAPERS = [
  { id: 'aurora', name: 'Aurora', css: 'radial-gradient(ellipse at 20% 20%, #1fa2a6 0%, transparent 55%), radial-gradient(ellipse at 80% 30%, #7b2ff7 0%, transparent 55%), radial-gradient(ellipse at 50% 100%, #0f3d5e 0%, transparent 60%), #0b1220' },
  { id: 'sunset', name: 'Sunset', css: 'linear-gradient(180deg, #1a1033 0%, #6b2a6b 35%, #e0566b 70%, #ffb26b 100%)' },
  { id: 'ocean', name: 'Ocean', css: 'linear-gradient(160deg, #021b3a 0%, #0a5a8a 50%, #12a4b6 100%)' },
  { id: 'midnight', name: 'Midnight', css: 'radial-gradient(circle at 50% 120%, #1b2a5a 0%, #0a0f24 60%, #05070f 100%)' },
  { id: 'forest', name: 'Forest', css: 'linear-gradient(160deg, #07210f 0%, #14532d 55%, #4d7c0f 100%)' },
  { id: 'ember', name: 'Ember', css: 'radial-gradient(circle at 30% 100%, #ff5e3a 0%, transparent 50%), radial-gradient(circle at 80% 90%, #ffb100 0%, transparent 40%), linear-gradient(#1b0b0b, #3a0d0d)' },
  { id: 'nebula', name: 'Nebula', css: 'radial-gradient(circle at 25% 30%, rgba(255,70,170,.55), transparent 45%), radial-gradient(circle at 75% 65%, rgba(70,120,255,.6), transparent 50%), radial-gradient(circle at 60% 15%, rgba(140,60,255,.45), transparent 40%), #0a0616' },
  { id: 'grid', name: 'Neon Grid', css: 'linear-gradient(rgba(0,255,200,.14) 1px, transparent 1px) 0 0 / 48px 48px, linear-gradient(90deg, rgba(0,255,200,.14) 1px, transparent 1px) 0 0 / 48px 48px, radial-gradient(circle at 50% 0%, #2a0a4a 0%, #090614 70%)' },
  { id: 'mono', name: 'Graphite', css: 'linear-gradient(135deg, #111 0%, #2a2a2a 50%, #111 100%)' },
  { id: 'sky', name: 'Sky', css: 'linear-gradient(180deg, #4facfe 0%, #00f2fe 100%)' },
  { id: 'candy', name: 'Candy', css: 'linear-gradient(135deg, #ff6a88 0%, #ff99ac 40%, #a18cd1 100%)' },
  { id: 'desert', name: 'Desert', css: 'linear-gradient(180deg, #2c1810 0%, #8a4b2a 55%, #e8a15a 100%)' },
  { id: 'slate', name: 'Slate', css: '#1e293b' }
];
