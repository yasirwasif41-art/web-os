// Optimizer app: live CPU/RAM, junk cleaner, game boost, end heavy apps.
(function () {
  const { el, esc } = OS;

  const fmt = (b) => {
    if (b >= 1e9) return (b / 1e9).toFixed(2) + ' GB';
    if (b >= 1e6) return (b / 1e6).toFixed(1) + ' MB';
    if (b >= 1e3) return Math.round(b / 1e3) + ' KB';
    return b + ' B';
  };

  OS.register({
    id: 'optimizer', title: 'Optimizer', icon: '⚡', width: 900, height: 640, single: true,
    create(w) {
      const api = window.api;
      const b = w.body;
      b.classList.add('op');
      b.innerHTML =
        '<div class="op-top">' +
        '<div class="gauge"><div class="gl">CPU usage</div><div class="gbar"><i data-k="cpu"></i></div><div class="gv" data-k="cpuv">–</div></div>' +
        '<div class="gauge"><div class="gl">Memory (RAM)</div><div class="gbar"><i data-k="ram"></i></div><div class="gv" data-k="ramv">–</div></div>' +
        '</div>' +
        '<div class="op-actions">' +
        '<div class="card"><h3>🧹 Junk cleaner</h3><p class="muted" data-k="junkinfo">Finds temp files and crash dumps you can safely delete.</p>' +
        '<div class="row"><button class="btn" data-a="scan">Scan</button><button class="btn pri" data-a="clean" disabled>Clean</button></div>' +
        '<div class="junklist" data-k="junk"></div></div>' +
        '<div class="card"><h3>🚀 Game boost</h3><p class="muted">Switches Windows to the High performance power plan and flushes the DNS cache. Then end heavy background apps below to free RAM and CPU.</p>' +
        '<div class="row"><button class="btn pri" data-a="boost">Boost now</button><button class="btn" data-a="dns">Flush DNS</button></div>' +
        '<div class="msg" data-k="boostmsg"></div></div>' +
        '</div>' +
        '<div class="card grow"><h3>Running apps <span class="muted" style="font-weight:400">— grouped by name, biggest memory first</span></h3>' +
        '<div class="proc head"><span>Name</span><span></span><span>Memory</span><span></span></div>' +
        '<div class="proc-list" data-k="procs"></div></div>';

      const q = (k) => b.querySelector(`[data-k="${k}"]`);
      let dead = false;
      let busy = false;

      function setBar(node, pct) {
        node.style.width = pct + '%';
        node.className = pct >= 90 ? 'hot' : pct >= 70 ? 'warn' : '';
      }

      function renderProcs(list) {
        const box = q('procs');
        box.innerHTML = '';
        for (const p of list) {
          const row = el('div', 'proc',
            `<span class="nm" title="${esc(p.name)}">${esc(p.name)}</span><span class="muted">${p.count > 1 ? '×' + p.count : ''}</span><span>${fmt(p.mem)}</span>`);
          const cell = el('span');
          if (p.protected) {
            cell.innerHTML = '<span class="muted" style="font-size:11px">system</span>';
          } else {
            const bt = el('button', 'btn sm danger', 'End');
            bt.addEventListener('click', async () => {
              const many = p.count > 1 ? ` (all ${p.count} processes)` : '';
              if (!confirm(`End ${p.name}${many}?\n\nAnything unsaved in it will be lost.`)) return;
              const r = await api.kill(p.name);
              OS.toast(r.ok ? `Ended ${p.name}` : `Couldn’t end ${p.name}: ${r.error}`);
              refresh();
            });
            cell.appendChild(bt);
          }
          row.appendChild(cell);
          box.appendChild(row);
        }
      }

      async function refresh() {
        if (busy || dead) return;
        busy = true;
        try {
          const [s, p] = await Promise.all([api.stats(), api.processes()]);
          if (dead) return;
          setBar(q('cpu'), s.cpu);
          q('cpuv').textContent = s.cpu + '%';
          const pct = Math.round((s.usedMem / s.totalMem) * 100);
          setBar(q('ram'), pct);
          q('ramv').textContent = `${fmt(s.usedMem)} / ${fmt(s.totalMem)}  (${pct}%)`;
          renderProcs(p);
        } catch (e) {
          console.error(e);
        } finally {
          busy = false;
        }
      }

      let scanned = [];
      async function scan() {
        q('junkinfo').textContent = 'Scanning…';
        scanned = await api.cleanScan();
        const total = scanned.reduce((a, x) => a + x.size, 0);
        q('junkinfo').textContent = total > 0 ? `Found ${fmt(total)} you can clean.` : 'Nothing to clean — your PC is tidy.';
        const box = q('junk');
        box.innerHTML = '';
        for (const x of scanned) {
          box.appendChild(el('div', null, `<span title="${esc(x.dir)}">${esc(x.name)} <span class="muted">(${x.files} files)</span></span><b>${fmt(x.size)}</b>`));
        }
        b.querySelector('[data-a=clean]').disabled = total <= 0;
      }

      b.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-a]');
        if (!a) return;
        const act = a.dataset.a;
        if (act === 'scan') {
          a.disabled = true;
          try { await scan(); } finally { a.disabled = false; }
        } else if (act === 'clean') {
          if (!confirm('Delete these temporary files?\n\nFiles that are currently in use are skipped automatically.')) return;
          a.disabled = true;
          q('junkinfo').textContent = 'Cleaning…';
          const r = await api.cleanRun();
          OS.toast(`Freed ${fmt(r.freed)}` + (r.skipped ? ` (${r.skipped} items were in use)` : ''));
          await scan();
        } else if (act === 'boost') {
          const r = await api.highPerf();
          const d = await api.flushDns();
          q('boostmsg').textContent = r.ok
            ? '✅ High performance power plan is on.' + (d.ok ? ' DNS cache flushed.' : '')
            : '⚠️ ' + r.error;
        } else if (act === 'dns') {
          const d = await api.flushDns();
          OS.toast(d.ok ? 'DNS cache flushed' : d.error);
        }
      });

      const timer = setInterval(refresh, 4000);
      w.onClose(() => { dead = true; clearInterval(timer); });
      refresh();
    }
  });
})();
