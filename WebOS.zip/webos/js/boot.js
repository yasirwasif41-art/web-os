// Start the desktop. Load custom icons first so the desktop never flashes the default ones.
(async function boot() {
  try { await OS.loadIcons(); } catch (e) { console.error(e); }
  OS.init();
  OS.applyWallpaper();
  OS.applyAccent();
  OS.applyIcons();
  OS.toast('Welcome to WebOS — double-click an icon or use the Start button');
})();
