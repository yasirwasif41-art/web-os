// Window manager, desktop, taskbar and start menu (Windows 11 style).
(function () {
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, html) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  };

  const OS = {
    apps: {},
    wins: new Map(),
    zTop: 10,
    nextId: 1,
    activeId: null,
    ready: false,
    iconMap: {},
    iconDir: '',
    iconListeners: [],
    hiddenByShowDesktop: [],
    esc, $, el,

    register(app) { this.apps[app.id] = app; },
    appList() { return Object.values(this.apps); },

    // ---------- icons (custom pictures from the icons folder) ----------
    iconHtml(app) {
      const u = this.iconMap[app.id];
      return u
        ? `<img class="aic" src="${esc(u)}" alt="" draggable="false">`
        : `<span class="aem">${esc(app.icon)}</span>`;
    },

    async loadIcons() {
      let r;
      try { r = await window.api.icons(); } catch { return; }
      const before = JSON.stringify(this.iconMap);
      this.iconMap = r.icons || {};
      this.iconDir = r.dir || '';
      if (before === JSON.stringify(this.iconMap)) return;
      if (this.ready) this.renderAllIcons();
      this.iconListeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } });
    },

    renderAllIcons() {
      this.renderIcons();
      this.renderStartMenu();
      this.renderTaskbar();
      for (const w of this.wins.values()) w.root.querySelector('.ticon').innerHTML = this.iconHtml(w.app);
    },

    init() {
      this.winLayer = $('#windows');
      this.tasks = $('#tasks');
      this.renderIcons();
      this.renderStartMenu();
      this.renderTaskbar();
      this.bindShell();
      this.tickClock();
      setInterval(() => this.tickClock(), 15000);
      Store.on('clock24', () => this.tickClock());
      window.api.onOpenUrl((url) => this.openUrl(url));
      window.api.onBrowserKey((k) => {
        const w = this.wins.get(this.activeId);
        if (w && w.app.id === 'browser' && w.api.key) w.api.key(k);
      });
      // pick up pictures dropped into the icons folder when the user comes back to WebOS
      window.addEventListener('focus', () => this.loadIcons());
      this.ready = true;
    },

    // ---------- desktop ----------
    renderIcons() {
      const box = $('#icons');
      box.innerHTML = '';
      for (const app of this.appList()) {
        const d = el('div', 'icon', `<div class="gl">${this.iconHtml(app)}</div><div class="lb">${esc(app.title)}</div>`);
        d.addEventListener('click', () => {
          box.querySelectorAll('.icon').forEach((i) => i.classList.remove('sel'));
          d.classList.add('sel');
        });
        d.addEventListener('dblclick', () => this.open(app.id));
        d.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          e.stopPropagation();
          box.querySelectorAll('.icon').forEach((i) => i.classList.remove('sel'));
          d.classList.add('sel');
          this.contextMenu(e.clientX, e.clientY, [{ label: '▶  Open', fn: () => this.open(app.id) }]);
        });
        box.appendChild(d);
      }
    },

    // ---------- start menu ----------
    renderStartMenu() {
      const q = $('#sm-search').value.trim();
      const box = $('#sm-apps');
      box.innerHTML = '';
      const list = this.appList().filter((a) => !q || a.title.toLowerCase().includes(q.toLowerCase()));
      $('.sm-title').textContent = q ? 'Apps' : 'Pinned';
      for (const app of list) {
        const b = el('button', 'sm-app', `<span class="gl">${this.iconHtml(app)}</span><span class="nm">${esc(app.title)}</span>`);
        b.addEventListener('click', () => { this.toggleStart(false); this.open(app.id); });
        box.appendChild(b);
      }
      if (q && !list.length) {
        const b = el('button', 'sm-app wide', `<span class="gl">🔎</span><span class="nm">Search the web for “${esc(q)}”</span>`);
        b.addEventListener('click', () => { this.toggleStart(false); this.openUrl(q); });
        box.appendChild(b);
      }
    },

    toggleStart(show) {
      const m = $('#startmenu');
      const want = show === undefined ? m.classList.contains('hidden') : show;
      m.classList.toggle('hidden', !want);
      $('#start-btn').classList.toggle('on', want);
      if (want) {
        $('#sm-search').value = '';
        this.renderStartMenu();
        setTimeout(() => $('#sm-search').focus(), 0);
      }
    },

    // ---------- taskbar ----------
    renderTaskbar() {
      const box = $('#tasks');
      box.innerHTML = '';
      for (const app of this.appList()) {
        const b = el('button', 'task', `<span class="gl">${this.iconHtml(app)}</span><i class="ind"></i>`);
        b.dataset.app = app.id;
        b.title = app.title;
        b.addEventListener('click', () => this.taskClick(app.id));
        b.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          const ws = this.appWins(app.id);
          const items = [{ label: `${app.icon}  ${ws.length && app.single ? 'Show' : 'Open'} ${app.title}`, fn: () => this.open(app.id) }];
          if (ws.length) items.push({ label: ws.length > 1 ? '✕  Close all windows' : '✕  Close window', fn: () => ws.forEach((w) => this.close(w.id)) });
          this.contextMenu(e.clientX, e.clientY, items);
        });
        box.appendChild(b);
      }
      this.updateTaskbar();
    },

    appWins(appId) { return [...this.wins.values()].filter((w) => w.app.id === appId); },

    taskClick(appId) {
      const ws = this.appWins(appId);
      if (!ws.length) { this.open(appId); return; }
      const cur = this.wins.get(this.activeId);
      if (ws.length === 1) {
        const w = ws[0];
        if (w.minimized || this.activeId !== w.id) this.focus(w.id); else this.minimize(w.id);
        return;
      }
      // several windows of one app: cycle through them
      if (cur && cur.app.id === appId && !cur.minimized) {
        const i = ws.indexOf(cur);
        this.focus(ws[(i + 1) % ws.length].id);
      } else {
        this.focus(ws.slice().sort((a, b) => +b.root.style.zIndex - +a.root.style.zIndex)[0].id);
      }
    },

    updateTaskbar() {
      const cur = this.wins.get(this.activeId);
      document.querySelectorAll('#tasks .task').forEach((b) => {
        const ws = this.appWins(b.dataset.app);
        b.classList.toggle('run', ws.length > 0);
        b.classList.toggle('active', !!cur && !cur.minimized && cur.app.id === b.dataset.app);
      });
    },

    showDesktop() {
      const open = [...this.wins.values()].filter((w) => !w.minimized);
      if (open.length) {
        this.hiddenByShowDesktop = open.map((w) => w.id);
        open.forEach((w) => this.minimize(w.id));
      } else {
        const ids = this.hiddenByShowDesktop.filter((id) => this.wins.has(id));
        this.hiddenByShowDesktop = [];
        ids.forEach((id) => this.focus(id));
      }
    },

    bindShell() {
      $('#start-btn').addEventListener('click', () => { this.hideCtx(); this.toggleStart(); });
      $('#show-desktop').addEventListener('click', () => this.showDesktop());
      $('#sm-search').addEventListener('input', () => this.renderStartMenu());
      $('#sm-search').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { const f = $('#sm-apps .sm-app'); if (f) f.click(); }
      });
      $('#sm-power').addEventListener('click', (e) => {
        const r = e.currentTarget.getBoundingClientRect();
        this.contextMenu(r.right - 190, r.bottom, [
          { label: '⛶  Toggle fullscreen', fn: () => window.api.toggleFullscreen() },
          { label: '⟳  Restart WebOS', fn: () => location.reload() },
          { label: '⏻  Shut down', fn: () => { if (confirm('Shut down WebOS?')) window.api.quit(); } }
        ]);
      });
      document.addEventListener('pointerdown', (e) => {
        if (!e.target.closest('#startmenu') && !e.target.closest('#start-btn') && !e.target.closest('#ctxmenu')) this.toggleStart(false);
        if (!e.target.closest('#ctxmenu')) this.hideCtx();
      });
      window.addEventListener('blur', () => { this.toggleStart(false); this.hideCtx(); });
      $('#desktop').addEventListener('pointerdown', (e) => {
        if (!e.target.closest('.icon')) document.querySelectorAll('.icon.sel').forEach((i) => i.classList.remove('sel'));
      });
      $('#desktop').addEventListener('contextmenu', (e) => {
        if (e.target.closest('.win') || e.target.closest('.icon')) return; // those have their own menus
        e.preventDefault();
        this.contextMenu(e.clientX, e.clientY, [
          { label: '🖼  Personalize…', fn: () => this.open('settings', { page: 'personal' }) },
          { label: '🎨  Change app icons…', fn: () => this.open('settings', { page: 'personal' }) },
          { sep: true },
          { label: '🌐  Open Browser', fn: () => this.open('browser') },
          { label: '🎮  Game Launcher', fn: () => this.open('games') },
          { label: '⚡  Optimizer', fn: () => this.open('optimizer') },
          { sep: true },
          { label: '⛶  Toggle fullscreen', fn: () => window.api.toggleFullscreen() }
        ]);
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { this.toggleStart(false); this.hideCtx(); }
        else if (e.ctrlKey && e.key === 'Escape') this.toggleStart();
      });
    },

    contextMenu(x, y, items) {
      const m = $('#ctxmenu');
      m.innerHTML = '';
      for (const it of items) {
        if (it.sep) { m.appendChild(el('div', 'sep')); continue; }
        const b = el('button', 'ci', esc(it.label));
        b.addEventListener('click', () => { this.hideCtx(); if (it.fn) it.fn(); });
        m.appendChild(b);
      }
      m.classList.remove('hidden');
      const r = m.getBoundingClientRect();
      m.style.left = Math.max(0, Math.min(x, innerWidth - r.width - 4)) + 'px';
      m.style.top = Math.max(0, Math.min(y, innerHeight - r.height - 4)) + 'px';
    },
    hideCtx() { $('#ctxmenu').classList.add('hidden'); },

    toast(msg, ms = 3200) {
      const t = el('div', 'toast', esc(msg));
      $('#toasts').appendChild(t);
      setTimeout(() => t.remove(), ms);
    },

    // ---------- appearance ----------
    applyWallpaper() {
      const wp = Store.get('wallpaper', { type: 'preset', id: 'aurora' });
      const d = $('#desktop');
      if (wp.type === 'file' && wp.url) {
        d.style.background = `url("${wp.url}") center / cover no-repeat, #000`;
      } else {
        const p = window.WALLPAPERS.find((x) => x.id === wp.id) || window.WALLPAPERS[0];
        d.style.background = p.css;
      }
    },
    applyAccent() {
      let c = Store.get('accent', '#4f8cff');
      if (!/^#[0-9a-f]{6}$/i.test(c)) c = '#4f8cff';
      const n = parseInt(c.slice(1), 16);
      const lum = 0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255);
      const r = document.documentElement.style;
      r.setProperty('--accent', c);
      r.setProperty('--accent-fg', lum > 150 ? '#0b1020' : '#ffffff');
    },
    applyIcons() { $('#icons').classList.toggle('hidden', Store.get('icons', true) === false); },

    tickClock() {
      const d = new Date();
      const h24 = Store.get('clock24', false);
      $('#clock').innerHTML =
        `<b>${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: !h24 })}</b>` +
        `<span>${d.toLocaleDateString([], { month: 'numeric', day: 'numeric', year: 'numeric' })}</span>`;
    },

    // ---------- windows ----------
    open(appId, opts = {}) {
      const app = this.apps[appId];
      if (!app) return null;
      if (app.single) {
        const ex = this.appWins(appId)[0];
        if (ex) {
          if (opts.page && ex.api.goto) ex.api.goto(opts.page);
          this.focus(ex.id);
          return ex;
        }
      }
      const id = this.nextId++;
      const root = el('div', 'win');
      root.innerHTML =
        '<div class="titlebar"><span class="ticon"></span><span class="ttitle"></span>' +
        '<div class="wbtns"><button class="wb min" title="Minimize">&#8211;</button><button class="wb max" title="Maximize">&#9744;</button><button class="wb close" title="Close">&#10005;</button></div></div>' +
        '<div class="wbody"></div>' +
        '<div class="rz rz-r" data-dir="r"></div><div class="rz rz-b" data-dir="b"></div><div class="rz rz-br" data-dir="br"></div>';
      root.querySelector('.ticon').innerHTML = this.iconHtml(app);

      const lay = this.winLayer.getBoundingClientRect();
      const width = Math.min(app.width || 800, lay.width - 20);
      const height = Math.min(app.height || 560, lay.height - 20);
      const n = this.wins.size % 8;
      root.style.width = width + 'px';
      root.style.height = height + 'px';
      root.style.left = Math.max(0, Math.min(40 + n * 28, lay.width - width)) + 'px';
      root.style.top = Math.max(0, Math.min(30 + n * 28, lay.height - height)) + 'px';

      const w = { id, app, root, body: root.querySelector('.wbody'), minimized: false, maximized: false, snap: null, prev: null, cleanups: [], api: {} };
      w.setTitle = (t) => { root.querySelector('.ttitle').textContent = t; };
      w.onClose = (fn) => w.cleanups.push(fn);
      w.close = () => this.close(id);

      root.addEventListener('pointerdown', () => this.focus(id), true);
      const tbar = root.querySelector('.titlebar');
      tbar.addEventListener('pointerdown', (e) => { if (!e.target.closest('.wbtns')) this.startDrag(w, e); });
      tbar.addEventListener('dblclick', (e) => { if (!e.target.closest('.wbtns')) this.toggleMax(id); });
      root.querySelector('.min').addEventListener('click', () => this.minimize(id));
      root.querySelector('.max').addEventListener('click', () => this.toggleMax(id));
      root.querySelector('.close').addEventListener('click', () => this.close(id));
      root.querySelectorAll('.rz').forEach((r) => r.addEventListener('pointerdown', (e) => this.startResize(w, e, r.dataset.dir)));

      w.setTitle(app.title);
      this.winLayer.appendChild(root);
      this.wins.set(id, w);
      try {
        app.create(w, opts);
      } catch (err) {
        console.error(err);
        w.body.textContent = 'This app crashed: ' + err.message;
      }
      this.focus(id);
      return w;
    },

    focus(id) {
      const w = this.wins.get(id);
      if (!w) return;
      if (w.minimized) { w.minimized = false; w.root.classList.remove('minimized'); }
      w.root.style.zIndex = ++this.zTop;
      this.activeId = id;
      for (const x of this.wins.values()) x.root.classList.toggle('active', x === w);
      this.updateTaskbar();
    },

    minimize(id) {
      const w = this.wins.get(id);
      if (!w) return;
      w.minimized = true;
      w.root.classList.add('minimized');
      w.root.classList.remove('active');
      if (this.activeId === id) { this.activeId = null; this.focusTop(); }
      this.updateTaskbar();
    },

    focusTop() {
      let best = null;
      for (const x of this.wins.values()) {
        if (!x.minimized && (!best || +x.root.style.zIndex > +best.root.style.zIndex)) best = x;
      }
      if (best) this.focus(best.id);
    },

    setMax(w, on) {
      w.maximized = on;
      w.root.classList.toggle('maximized', on);
      w.root.querySelector('.max').innerHTML = on ? '&#10064;' : '&#9744;';
    },

    toggleMax(id) {
      const w = this.wins.get(id);
      if (!w) return;
      if (w.snap) this.unsnap(w);
      this.setMax(w, !w.maximized);
    },

    snap(w, side) {
      const lay = this.winLayer.getBoundingClientRect();
      if (!w.snap) w.prev = { left: w.root.style.left, top: w.root.style.top, width: w.root.style.width, height: w.root.style.height };
      const half = Math.floor(lay.width / 2);
      w.root.style.left = (side === 'l' ? 0 : half) + 'px';
      w.root.style.top = '0px';
      w.root.style.width = half + 'px';
      w.root.style.height = lay.height + 'px';
      w.snap = side;
      w.root.classList.add('snapped');
    },

    unsnap(w) {
      if (!w.snap) return;
      if (w.prev) Object.assign(w.root.style, w.prev);
      w.snap = null;
      w.root.classList.remove('snapped');
    },

    close(id) {
      const w = this.wins.get(id);
      if (!w) return;
      for (const fn of w.cleanups) { try { fn(); } catch (e) { console.error(e); } }
      w.root.remove();
      this.wins.delete(id);
      if (this.activeId === id) { this.activeId = null; this.focusTop(); }
      this.updateTaskbar();
    },

    openUrl(url) {
      let target = this.wins.get(this.activeId);
      if (!target || target.app.id !== 'browser') {
        target = this.appWins('browser').pop();
      }
      if (target) { target.api.newTab(url); this.focus(target.id); } else this.open('browser', { url });
    },

    // ---------- drag / snap / resize ----------
    startDrag(w, e) {
      if (e.button !== 0) return;
      const lay = this.winLayer.getBoundingClientRect();
      const startX = e.clientX;
      const startY = e.clientY;
      const old = w.root.getBoundingClientRect();
      let moved = false;
      let dx = startX - old.left;
      let dy = startY - old.top;
      let zone = null;
      const preview = $('#snap');

      const showZone = (z) => {
        zone = z;
        if (!z) { preview.classList.add('hidden'); return; }
        const half = lay.width / 2;
        preview.style.left = (z === 'r' ? lay.left + half : lay.left) + 'px';
        preview.style.top = lay.top + 'px';
        preview.style.width = (z === 'max' ? lay.width : half) + 'px';
        preview.style.height = lay.height + 'px';
        preview.classList.remove('hidden');
      };

      const move = (ev) => {
        if (!moved) {
          if (Math.abs(ev.clientX - startX) + Math.abs(ev.clientY - startY) < 4) return;
          moved = true;
          document.body.classList.add('dragging');
          if (w.maximized || w.snap) {
            // pull the window out of maximized / snapped state, keeping it under the cursor
            const ratio = (startX - old.left) / old.width;
            if (w.maximized) this.setMax(w, false);
            this.unsnap(w);
            const r = w.root.getBoundingClientRect();
            dx = r.width * ratio;
            dy = Math.min(startY - old.top, 30);
          }
        }
        const r = w.root.getBoundingClientRect();
        let x = ev.clientX - dx - lay.left;
        let y = ev.clientY - dy - lay.top;
        x = Math.min(Math.max(x, -r.width + 120), lay.width - 60);
        y = Math.min(Math.max(y, 0), lay.height - 34);
        w.root.style.left = x + 'px';
        w.root.style.top = y + 'px';
        const z = ev.clientY <= lay.top + 2 ? 'max' : ev.clientX <= lay.left + 2 ? 'l' : ev.clientX >= lay.right - 3 ? 'r' : null;
        if (z !== zone) showZone(z);
      };
      const up = () => {
        document.body.classList.remove('dragging');
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', up);
        const z = zone;
        showZone(null);
        if (z === 'max') this.setMax(w, true);
        else if (z) this.snap(w, z);
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
      window.addEventListener('pointercancel', up);
    },

    startResize(w, e, dir) {
      e.preventDefault();
      e.stopPropagation();
      if (e.button !== 0 || w.maximized) return;
      if (w.snap) { w.snap = null; w.root.classList.remove('snapped'); }
      const r = w.root.getBoundingClientRect();
      const sx = e.clientX;
      const sy = e.clientY;
      document.body.classList.add('dragging');
      const move = (ev) => {
        if (dir.includes('r')) w.root.style.width = Math.max(380, r.width + ev.clientX - sx) + 'px';
        if (dir.includes('b')) w.root.style.height = Math.max(260, r.height + ev.clientY - sy) + 'px';
      };
      const up = () => {
        document.body.classList.remove('dragging');
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    }
  };

  window.OS = OS;
})();
