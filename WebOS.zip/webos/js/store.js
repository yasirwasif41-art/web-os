// Tiny persistent key/value store (localStorage) with change listeners.
(function () {
  const PREFIX = 'webos.';
  const listeners = {};

  window.Store = {
    get(key, def) {
      try {
        const v = localStorage.getItem(PREFIX + key);
        return v === null ? def : JSON.parse(v);
      } catch { return def; }
    },
    set(key, val) {
      try { localStorage.setItem(PREFIX + key, JSON.stringify(val)); } catch (e) { console.warn('Store write failed', e); }
      (listeners[key] || []).slice().forEach((cb) => { try { cb(val); } catch (e) { console.error(e); } });
    },
    // returns an unsubscribe function
    on(key, cb) {
      (listeners[key] = listeners[key] || []).push(cb);
      return () => { listeners[key] = (listeners[key] || []).filter((f) => f !== cb); };
    }
  };
})();
