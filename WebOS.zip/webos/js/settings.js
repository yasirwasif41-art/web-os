// Settings app: wallpapers, accent colour, clock, browser options, system info.
(function () {
  const { el, esc } = OS;

  const fmtGB = (b) => (b / 1e9).toFixed(1) + ' GB';
  const ACCENTS = ['#4f8cff', '#7c5cff', '#e5489a', '#ef4a5a', '#ff8a3d', '#f2c230', '#34c38f', '#18b6c9'];

  OS.register({
    id: 'settings', title: 'Settings', icon: '⚙️', width: 860, height: 580, single: true,
    create(w, opts) {
      const b = w.body;
      b.classList.add('st');
      b.innerHTML = '<div class="st-nav"></div><div class="st-page"></div>';
      const nav = b.querySelector('.st-nav');
      const page = b.querySelector('.st-page');

      const pages = {
        personal: { label: '🎨  Personalization', render: personal },
        browser: { label: '🌐  Browser', render: browser },
        system: { label: '🖥  System', render: system },
        about: { label: 'ℹ️  About', render: about }
      };

      let current = 'personal';
      function show(id) {
        if (!pages[id]) id = 'personal';
        current = id;
        nav.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x.dataset.id === id));
        page.innerHTML = '';
        pages[id].render(page);
      }
      for (const [id, p] of Object.entries(pages)) {
        const btn = el('button', null, esc(p.label));
        btn.dataset.id = id;
        btn.addEventListener('click', () => show(id));
        nav.appendChild(btn);
      }
      w.api.goto = show;
      // re-draw the icon list when the icons folder changes while this page is open
      const onIcons = () => { if (current === 'personal') show('personal'); };
      OS.iconListeners.push(onIcons);
      w.onClose(() => { OS.iconListeners = OS.iconListeners.filter((f) => f !== onIcons); });

      function personal(box) {
        const wp = Store.get('wallpaper', { type: 'preset', id: 'aurora' });
        const accent = Store.get('accent', '#4f8cff');
        box.innerHTML =
          '<h2>Wallpaper</h2><div class="wp-grid"></div>' +
          '<div class="row" style="margin-top:12px"><button class="btn" data-a="img">🖼 Use my own image…</button><span class="muted wp-cur"></span></div>' +
          '<h2>Accent colour</h2><div class="swatches"></div>' +
          '<h2>App icons</h2>' +
          '<p class="muted">Drop pictures into the <b>icons</b> folder and name each one after its app. They replace the default icons everywhere (desktop, taskbar, Start menu, windows).</p>' +
          '<div class="ic-list"></div>' +
          '<div class="row" style="margin-top:10px"><button class="btn pri" data-a="openicons">📂 Open icons folder</button><button class="btn" data-a="refreshicons">⟳ Refresh</button></div>' +
          '<p class="muted ic-dir" style="margin-top:8px;font-size:12px;user-select:text"></p>' +
          '<h2>Desktop &amp; taskbar</h2>' +
          '<label class="chk"><input type="checkbox" data-k="clock24"> 24-hour clock</label>' +
          '<label class="chk"><input type="checkbox" data-k="icons"> Show desktop icons</label>';

        const FILES = { browser: 'browser.png', optimizer: 'optimizer.png', games: 'games.png', settings: 'settings.png' };
        const list = box.querySelector('.ic-list');
        for (const app of OS.appList()) {
          const custom = !!OS.iconMap[app.id];
          list.appendChild(el('div', 'ic-row',
            `<span class="pv">${OS.iconHtml(app)}</span>` +
            `<span class="nm">${esc(app.title)}</span>` +
            `<code>${esc(FILES[app.id] || app.id + '.png')}</code>` +
            `<span class="${custom ? 'ok' : 'muted'}">${custom ? 'Custom icon' : 'Default'}</span>`));
        }
        box.querySelector('.ic-dir').textContent = OS.iconDir ? 'Folder: ' + OS.iconDir : '';
        box.querySelector('[data-a=openicons]').addEventListener('click', async () => {
          const r = await window.api.openIconsFolder();
          if (!r.ok) OS.toast('Couldn’t open the folder: ' + r.error);
        });
        box.querySelector('[data-a=refreshicons]').addEventListener('click', async () => {
          await OS.loadIcons();
          show('personal');
          OS.toast('Icons refreshed');
        });

        const grid = box.querySelector('.wp-grid');
        for (const p of window.WALLPAPERS) {
          const it = el('div', 'wp-item' + (wp.type === 'preset' && wp.id === p.id ? ' on' : ''), `<div class="th"></div><div class="nm">${esc(p.name)}</div>`);
          it.querySelector('.th').style.background = p.css;
          it.addEventListener('click', () => { Store.set('wallpaper', { type: 'preset', id: p.id }); OS.applyWallpaper(); show('personal'); });
          grid.appendChild(it);
        }
        box.querySelector('.wp-cur').textContent = wp.type === 'file' ? 'Current: ' + (wp.name || 'your image') : '';
        box.querySelector('[data-a=img]').addEventListener('click', async () => {
          const r = await window.api.pickWallpaper();
          if (r) { Store.set('wallpaper', { type: 'file', url: r.url, name: r.name }); OS.applyWallpaper(); show('personal'); }
        });

        const sw = box.querySelector('.swatches');
        for (const c of ACCENTS) {
          const s = el('button', 'sw' + (c.toLowerCase() === accent.toLowerCase() ? ' on' : ''));
          s.style.background = c;
          s.title = c;
          s.addEventListener('click', () => { Store.set('accent', c); OS.applyAccent(); show('personal'); });
          sw.appendChild(s);
        }
        const custom = el('input');
        custom.type = 'color';
        custom.value = /^#[0-9a-f]{6}$/i.test(accent) ? accent : '#4f8cff';
        custom.title = 'Custom colour';
        custom.addEventListener('change', () => { Store.set('accent', custom.value); OS.applyAccent(); show('personal'); });
        sw.appendChild(custom);

        const c24 = box.querySelector('[data-k=clock24]');
        c24.checked = !!Store.get('clock24', false);
        c24.addEventListener('change', () => Store.set('clock24', c24.checked));
        const ic = box.querySelector('[data-k=icons]');
        ic.checked = Store.get('icons', true) !== false;
        ic.addEventListener('change', () => { Store.set('icons', ic.checked); OS.applyIcons(); });
      }

      function browser(box) {
        box.innerHTML =
          '<h2>Default search engine</h2><div class="row"><select class="eng"></select></div>' +
          '<h2>Saved sites</h2><p class="muted">You have <b class="cnt"></b> saved site(s).</p>' +
          '<div class="row"><button class="btn" data-a="clearsaved">Remove all saved sites</button></div>' +
          '<h2>Browsing data</h2><p class="muted">Clears cookies, logins and cached files used by the Browser app.</p>' +
          '<div class="row"><button class="btn" data-a="cleardata">Clear browsing data</button></div>';
        const sel = box.querySelector('.eng');
        for (const [id, e] of Object.entries(window.SEARCH_ENGINES)) {
          const o = el('option', null, esc(e.name));
          o.value = id;
          sel.appendChild(o);
        }
        sel.value = Store.get('engine', 'google');
        sel.addEventListener('change', () => Store.set('engine', sel.value));
        box.querySelector('.cnt').textContent = Store.get('saved', []).length;
        box.querySelector('[data-a=clearsaved]').addEventListener('click', () => {
          if (confirm('Remove all saved sites?')) { Store.set('saved', []); show('browser'); }
        });
        box.querySelector('[data-a=cleardata]').addEventListener('click', async () => {
          if (confirm('Sign out of websites and clear cached files?')) {
            await window.api.clearBrowsingData();
            OS.toast('Browsing data cleared');
          }
        });
      }

      function system(box) {
        box.innerHTML =
          '<h2>Display</h2><div class="row"><button class="btn" data-a="full">⛶ Toggle fullscreen (F11)</button></div>' +
          '<h2>Reset</h2><p class="muted">Puts wallpaper, accent colour and other settings back to default. Your saved sites and game list are kept.</p>' +
          '<div class="row"><button class="btn danger" data-a="reset">Reset settings</button></div>';
        box.querySelector('[data-a=full]').addEventListener('click', () => window.api.toggleFullscreen());
        box.querySelector('[data-a=reset]').addEventListener('click', () => {
          if (!confirm('Reset all WebOS settings?')) return;
          Object.keys(localStorage)
            .filter((k) => k.startsWith('webos.') && !['webos.saved', 'webos.games'].includes(k))
            .forEach((k) => localStorage.removeItem(k));
          location.reload();
        });
      }

      async function about(box) {
        box.innerHTML = '<h2>About this PC</h2><div class="kv">Loading…</div>';
        const i = await window.api.sysInfo();
        box.innerHTML =
          '<h2>About this PC</h2><div class="kv">' +
          `<span>WebOS</span><span>v${esc(i.version)}</span>` +
          `<span>System</span><span>${esc(i.platform)}</span>` +
          `<span>Computer name</span><span>${esc(i.hostname)}</span>` +
          `<span>Processor</span><span>${esc(i.cpuModel)} (${i.cores} threads)</span>` +
          `<span>Memory</span><span>${fmtGB(i.totalMem)}</span>` +
          `<span>Electron / Chromium</span><span>${esc(i.electron)} / ${esc(i.chrome)}</span></div>`;
      }

      show((opts && opts.page) || 'personal');
    }
  });
})();
