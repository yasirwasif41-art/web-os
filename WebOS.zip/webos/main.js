const { app, BrowserWindow, Menu, ipcMain, dialog, shell, session, clipboard, net } = require('electron');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, execFile } = require('child_process');
const { pathToFileURL } = require('url');

const isWin = process.platform === 'win32';
const BROWSER_PARTITION = 'persist:webos-browser';
let win = null;

// ---------- single instance ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
}

// ---------- window ----------
function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1280,
    height: 800,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#0b1220',
    title: 'WebOS',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true
    }
  });

  win.once('ready-to-show', () => {
    win.maximize();
    win.show();
  });

  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());

  // Lock down every <webview> the shell creates.
  win.webContents.on('will-attach-webview', (e, webPreferences, params) => {
    delete webPreferences.preload;
    webPreferences.nodeIntegration = false;
    webPreferences.contextIsolation = true;
    webPreferences.sandbox = true;
    if (params.src && !/^(https?:|about:blank)/i.test(params.src)) e.preventDefault();
  });

  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') {
      win.setFullScreen(!win.isFullScreen());
      e.preventDefault();
    }
  });

  win.on('closed', () => { win = null; });
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  // Browser session: only allow harmless permissions
  const ses = session.fromPartition(BROWSER_PARTITION);
  const allowed = new Set(['fullscreen', 'clipboard-sanitized-write', 'pointerLock']);
  ses.setPermissionRequestHandler((_wc, permission, cb) => cb(allowed.has(permission)));

  ensureIconsDir();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => app.quit());

// Pages inside the Browser app: new-window links become tabs, plus a right-click menu and shortcuts
app.on('web-contents-created', (_e, contents) => {
  if (contents.getType() !== 'webview') return;
  const send = (ch, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); };

  contents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) send('open-url', url);
    return { action: 'deny' };
  });

  // Ctrl+T / W / L / R and Alt+Arrows would otherwise be swallowed by the page
  contents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    const k = String(input.key || '').toLowerCase();
    let cmd = null;
    if ((input.control || input.meta) && !input.alt && ['t', 'w', 'l', 'r'].includes(k)) cmd = k;
    else if (k === 'f5') cmd = 'r';
    else if (input.alt && k === 'arrowleft') cmd = 'back';
    else if (input.alt && k === 'arrowright') cmd = 'fwd';
    if (cmd) { e.preventDefault(); send('browser-key', cmd); }
  });

  contents.on('context-menu', (_ev, p) => {
    const t = [];
    const nav = contents.navigationHistory;
    if (p.linkURL && /^https?:/i.test(p.linkURL)) {
      t.push(
        { label: 'Open link in new tab', click: () => send('open-url', p.linkURL) },
        { label: 'Copy link address', click: () => clipboard.writeText(p.linkURL) },
        { type: 'separator' }
      );
    }
    if (p.mediaType === 'image' && p.srcURL && /^https?:/i.test(p.srcURL)) {
      t.push(
        { label: 'Open image in new tab', click: () => send('open-url', p.srcURL) },
        { label: 'Copy image', click: () => contents.copyImageAt(p.x, p.y) },
        { type: 'separator' }
      );
    }
    if (p.isEditable) {
      t.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' });
    } else if (p.selectionText) {
      const s = p.selectionText.trim();
      t.push({ role: 'copy' });
      if (s) t.push({ label: `Search for “${s.length > 28 ? s.slice(0, 28) + '…' : s}”`, click: () => send('open-url', s) });
    } else {
      t.push(
        { label: 'Back', enabled: nav ? nav.canGoBack() : contents.canGoBack(), click: () => contents.goBack() },
        { label: 'Forward', enabled: nav ? nav.canGoForward() : contents.canGoForward(), click: () => contents.goForward() },
        { label: 'Reload', click: () => contents.reload() }
      );
    }
    if (t.length) Menu.buildFromTemplate(t).popup({ window: win });
  });
});

// ---------- helpers ----------
function run(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    execFile(cmd, args, { windowsHide: true, maxBuffer: 32 * 1024 * 1024, timeout: 20000, ...opts }, (err, stdout, stderr) => {
      resolve({ err, stdout: String(stdout || ''), stderr: String(stderr || '') });
    });
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function dirSize(dir) {
  let size = 0;
  let files = 0;
  let seen = 0;
  const stack = [dir];
  while (stack.length) {
    const d = stack.pop();
    let ents;
    try { ents = await fs.promises.readdir(d, { withFileTypes: true }); } catch { continue; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) stack.push(p);
      else if (e.isFile()) {
        try { size += (await fs.promises.stat(p)).size; files++; } catch { /* in use */ }
      }
      if (++seen > 300000) return { size, files, capped: true };
    }
  }
  return { size, files };
}

function cleanTargets() {
  const t = [{ id: 'usertemp', name: 'User temp files', dir: os.tmpdir() }];
  if (isWin) {
    t.push({ id: 'wintemp', name: 'Windows temp files', dir: path.join(process.env.SystemRoot || 'C:\\Windows', 'Temp') });
    if (process.env.LOCALAPPDATA) t.push({ id: 'crash', name: 'Crash dumps', dir: path.join(process.env.LOCALAPPDATA, 'CrashDumps') });
  }
  const seen = new Set();
  return t.filter((x) => {
    const k = x.dir.toLowerCase();
    if (seen.has(k) || !fs.existsSync(x.dir)) return false;
    seen.add(k);
    return true;
  });
}

// ---------- system stats / processes ----------
const PROTECTED = new Set([
  'system', 'system idle process', 'registry', 'memory compression', 'secure system', 'smss.exe', 'csrss.exe',
  'wininit.exe', 'services.exe', 'lsass.exe', 'winlogon.exe', 'svchost.exe', 'dwm.exe', 'explorer.exe',
  'fontdrvhost.exe', 'taskhostw.exe', 'sihost.exe', 'audiodg.exe', 'spoolsv.exe', 'msmpeng.exe', 'conhost.exe',
  'runtimebroker.exe', 'wudfhost.exe', 'lsm.exe', 'ctfmon.exe', 'searchindexer.exe', 'securityhealthservice.exe',
  'systemd', 'init', 'bash', 'sh',
  path.basename(process.execPath).toLowerCase(), 'electron.exe', 'webos.exe', 'electron'
]);

ipcMain.handle('sys:stats', async () => {
  const a = os.cpus();
  await sleep(300);
  const b = os.cpus();
  let idle = 0;
  let total = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i].times;
    const y = b[i].times;
    const di = y.idle - x.idle;
    idle += di;
    total += (y.user - x.user) + (y.nice - x.nice) + (y.sys - x.sys) + (y.irq - x.irq) + di;
  }
  const totalMem = os.totalmem();
  return {
    cpu: total > 0 ? Math.round((1 - idle / total) * 100) : 0,
    totalMem,
    usedMem: totalMem - os.freemem(),
    uptime: os.uptime()
  };
});

ipcMain.handle('sys:info', () => ({
  platform: `${os.type()} ${os.release()}`,
  hostname: os.hostname(),
  cpuModel: (os.cpus()[0] || {}).model || 'Unknown',
  cores: os.cpus().length,
  totalMem: os.totalmem(),
  electron: process.versions.electron,
  chrome: process.versions.chrome,
  version: app.getVersion()
}));

ipcMain.handle('sys:processes', async () => {
  const raw = [];
  if (isWin) {
    const { stdout } = await run('tasklist', ['/FO', 'CSV', '/NH']);
    for (const line of stdout.split(/\r?\n/)) {
      const m = line.match(/"([^"]*)"/g);
      if (!m || m.length < 5) continue;
      const f = m.map((s) => s.slice(1, -1));
      const kb = parseInt(f[4].replace(/[^\d]/g, ''), 10);
      raw.push({ name: f[0], mem: isNaN(kb) ? 0 : kb * 1024 });
    }
  } else {
    const { stdout } = await run('ps', ['-eo', 'rss=,comm=']);
    for (const line of stdout.split('\n')) {
      const m = line.match(/^\s*(\d+)\s+(.+)$/);
      if (m) raw.push({ name: m[2].trim(), mem: parseInt(m[1], 10) * 1024 });
    }
  }
  const groups = new Map();
  for (const p of raw) {
    const k = p.name.toLowerCase();
    const g = groups.get(k) || { name: p.name, count: 0, mem: 0, protected: PROTECTED.has(k) };
    g.count++;
    g.mem += p.mem;
    groups.set(k, g);
  }
  return [...groups.values()].filter((g) => g.mem > 0).sort((a, b) => b.mem - a.mem).slice(0, 40);
});

ipcMain.handle('sys:kill', async (_e, name) => {
  name = String(name || '');
  if (!name || /[\\/"&|<>^%*?]/.test(name)) return { ok: false, error: 'Invalid process name' };
  if (PROTECTED.has(name.toLowerCase())) return { ok: false, error: 'Protected system process' };
  const r = isWin ? await run('taskkill', ['/F', '/IM', name]) : await run('pkill', ['-x', name]);
  if (r.err) return { ok: false, error: (r.stderr || r.stdout || r.err.message).trim().split('\n')[0] };
  return { ok: true };
});

// ---------- junk cleaner ----------
ipcMain.handle('clean:scan', async () => {
  const out = [];
  for (const t of cleanTargets()) {
    const s = await dirSize(t.dir);
    out.push({ id: t.id, name: t.name, dir: t.dir, size: s.size, files: s.files });
  }
  return out;
});

ipcMain.handle('clean:run', async () => {
  const targets = cleanTargets();
  let before = 0;
  for (const t of targets) before += (await dirSize(t.dir)).size;
  let skipped = 0;
  for (const t of targets) {
    let ents = [];
    try { ents = await fs.promises.readdir(t.dir); } catch { continue; }
    for (const name of ents) {
      try { await fs.promises.rm(path.join(t.dir, name), { recursive: true, force: true }); } catch { skipped++; }
    }
  }
  let after = 0;
  for (const t of targets) after += (await dirSize(t.dir)).size;
  return { freed: Math.max(0, before - after), skipped };
});

// ---------- boost ----------
const HIGH_PERF = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c';
ipcMain.handle('power:highperf', async () => {
  if (!isWin) return { ok: false, error: 'Power plans are Windows only' };
  let r = await run('powercfg', ['/setactive', HIGH_PERF]);
  if (r.err) {
    // Plan may be hidden on some PCs: create it from the template and activate that copy
    const dup = await run('powercfg', ['/duplicatescheme', HIGH_PERF]);
    const m = dup.stdout.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
    if (m) r = await run('powercfg', ['/setactive', m[1]]);
  }
  return r.err ? { ok: false, error: 'Windows refused the change (try running WebOS as administrator)' } : { ok: true };
});

ipcMain.handle('dns:flush', async () => {
  if (!isWin) return { ok: false, error: 'Windows only' };
  const r = await run('ipconfig', ['/flushdns']);
  return r.err ? { ok: false, error: 'Could not flush DNS' } : { ok: true };
});

// ---------- game / exe finder ----------
const JUNK_EXE = /(unins|uninst|setup|install|redist|vcredist|vc_redist|dxsetup|dxwebsetup|dotnet|crashhandler|crashreport|crashpad|crash_report|unitycrash|helper|updater|update|webhelper|notification|easyanticheat|eac_launcher|battleye|beservice|benchmark|prereq|7z|elevate|diagnostic|oalinst|physx|touchup|gamingrepair)/i;
const SKIP_DIRS = new Set([
  '$recycle.bin', 'system volume information', 'windows', 'node_modules', '.git', '__pycache__', 'redist', '_redist',
  '_commonredist', 'commonredist', 'redistributables', 'directx', 'dotnet', 'vcredist', 'installer', 'installers',
  'engine', 'thirdparty', 'crashreportclient', '__installer', 'easyanticheat', 'battleye', 'webview2',
  'windowsapps', 'windows kits', 'common files', 'microsoft'
]);

function prettyName(s) { return s.replace(/[_]+/g, ' ').trim() || s; }

async function findExes(root, maxDepth, state) {
  const out = [];
  async function walk(dir, depth) {
    if (depth > maxDepth || state.count > 200000) return;
    let ents;
    try { ents = await fs.promises.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      state.count++;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (!SKIP_DIRS.has(e.name.toLowerCase())) await walk(full, depth + 1);
      } else if (e.isFile() && /\.exe$/i.test(e.name) && !JUNK_EXE.test(e.name)) {
        out.push(full);
      }
    }
  }
  await walk(root, 0);
  return out;
}

ipcMain.handle('games:defaultRoots', () => {
  const games = [];
  const apps = [];
  if (isWin) {
    const rels = [
      'Games', 'Game', 'SteamLibrary\\steamapps\\common', 'Steam\\steamapps\\common',
      'Program Files\\Steam\\steamapps\\common', 'Program Files (x86)\\Steam\\steamapps\\common',
      'Epic Games', 'Program Files\\Epic Games', 'GOG Games', 'GOG Galaxy\\Games',
      'Program Files (x86)\\GOG Galaxy\\Games', 'Program Files\\Ubisoft\\Ubisoft Game Launcher\\games',
      'Program Files (x86)\\Ubisoft\\Ubisoft Game Launcher\\games', 'Program Files (x86)\\Origin Games',
      'Program Files\\EA Games', 'XboxGames'
    ];
    for (const d of 'CDEFGH') for (const rel of rels) {
      const p = `${d}:\\${rel}`;
      if (fs.existsSync(p)) games.push(p);
    }
    for (const p of [process.env.ProgramFiles, process.env['ProgramFiles(x86)']]) if (p && fs.existsSync(p)) apps.push(p);
  } else {
    const g = path.join(os.homedir(), 'Games');
    if (fs.existsSync(g)) games.push(g);
  }
  return { games, apps };
});

ipcMain.handle('games:scan', async (_e, roots) => {
  const state = { count: 0 };
  const groups = new Map();
  const seenExe = new Set();
  for (const root of Array.isArray(roots) ? roots : []) {
    if (typeof root !== 'string' || !fs.existsSync(root)) continue;
    for (const full of await findExes(root, 4, state)) {
      if (seenExe.has(full.toLowerCase())) continue;
      seenExe.add(full.toLowerCase());
      const rel = path.relative(root, full).split(path.sep);
      let key, name, dir;
      if (rel.length === 1) {
        key = full.toLowerCase();
        name = prettyName(path.basename(full, path.extname(full)));
        dir = root;
      } else {
        dir = path.join(root, rel[0]);
        key = dir.toLowerCase();
        name = rel[0];
      }
      let g = groups.get(key);
      if (!g) { g = { id: key, name, dir, exes: [] }; groups.set(key, g); }
      let size = 0;
      try { size = (await fs.promises.stat(full)).size; } catch { /* ignore */ }
      g.exes.push({ path: full, depth: rel.length, size });
    }
  }
  const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const items = [];
  for (const g of groups.values()) {
    const n = norm(g.name);
    for (const e of g.exes) {
      const b = norm(path.basename(e.path, '.exe'));
      let s = 0;
      if (b === n) s += 1000;
      else if (b && n && (n.includes(b) || b.includes(n))) s += 300;
      s += (10 - e.depth) * 10;
      s += Math.min(e.size / 1e6, 200) / 10;
      e.score = s;
    }
    g.exes.sort((a, b) => b.score - a.score);
    items.push({
      id: g.id, name: g.name, dir: g.dir,
      exe: g.exes[0].path, alts: g.exes.slice(1, 10).map((e) => e.path), size: g.exes[0].size
    });
    if (items.length >= 2000) break;
  }
  return items;
});

ipcMain.handle('games:launch', async (_e, exe) => {
  try {
    if (typeof exe !== 'string' || !/\.exe$/i.test(exe) || exe.includes('"') || !fs.existsSync(exe)) {
      return { ok: false, error: 'File not found' };
    }
    const dir = path.dirname(exe);
    let child;
    if (isWin) {
      // "start" goes through ShellExecute, so programs that need admin rights get the normal UAC prompt
      const cmd = `start "" /D "${dir}" "${exe}"`;
      child = spawn('cmd.exe', ['/d', '/s', '/c', `"${cmd}"`], {
        detached: true, stdio: 'ignore', windowsHide: true, windowsVerbatimArguments: true, cwd: dir
      });
    } else {
      child = spawn(exe, [], { cwd: dir, detached: true, stdio: 'ignore' });
    }
    child.on('error', () => {});
    child.unref();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('games:reveal', (_e, p) => {
  if (typeof p === 'string' && fs.existsSync(p)) shell.showItemInFolder(p);
});

ipcMain.handle('games:pickFolder', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choose a folder to scan', properties: ['openDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('games:pickExe', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Choose a program', properties: ['openFile'], filters: [{ name: 'Programs', extensions: ['exe'] }]
  });
  if (r.canceled) return null;
  const p = r.filePaths[0];
  let size = 0;
  try { size = fs.statSync(p).size; } catch { /* ignore */ }
  return { path: p, dir: path.dirname(p), size, name: prettyName(path.basename(p, path.extname(p))) };
});

// ---------- settings helpers ----------
ipcMain.handle('wallpaper:pick', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Choose a wallpaper', properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'bmp', 'gif'] }]
  });
  if (r.canceled) return null;
  return { url: pathToFileURL(r.filePaths[0]).href, name: path.basename(r.filePaths[0]) };
});

ipcMain.handle('browser:clearData', async () => {
  const ses = session.fromPartition(BROWSER_PARTITION);
  await ses.clearStorageData();
  await ses.clearCache();
  return true;
});

// ---------- game cover art (internet lookup, cached on disk) ----------
const coversDir = () => path.join(app.getPath('userData'), 'covers');
const NET_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

async function netGet(url, ms = 12000) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), ms);
  try {
    const r = await net.fetch(url, { signal: ac.signal, headers: { 'User-Agent': NET_UA, 'Accept-Language': 'en-US,en;q=0.9' } });
    if (!r.ok) return { ok: false, status: r.status };
    return { ok: true, buf: Buffer.from(await r.arrayBuffer()) };
  } catch (e) {
    return { ok: false, network: true, error: e.message };
  } finally {
    clearTimeout(timer);
  }
}

function isImage(b) {
  if (!b || b.length < 1500) return false;
  return (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) ||                      // jpeg
    (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) ||            // png
    (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP'); // webp
}

// "Cyberpunk.2077.v1.6.x64-REPACK" -> "Cyberpunk 2077"
function cleanGameName(s) {
  return String(s)
    .replace(/[\[(].*?[\])]/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[_.]+/g, ' ')
    .replace(/\bv?\d+(\s\d+){1,3}\b(?=\s|$)/gi, (m) => (/^\d{4}$/.test(m) ? m : ' '))
    .replace(/\b(x64|x86|win64|win32|64bit|32bit|gog|repack|fitgirl|dodi|goty|setup|launcher)\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^[\s\-–:]+|[\s\-–:]+$/g, '')
    .trim();
}

const normName = (s) => String(s).toLowerCase().replace(/[™®©]/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').trim();

function similarity(a, b) {
  a = normName(a); b = normName(b);
  if (!a || !b) return 0;
  if (a === b) return 100;
  const ta = new Set(a.split(' '));
  const tb = new Set(b.split(' '));
  let inter = 0;
  ta.forEach((t) => { if (tb.has(t)) inter++; });
  let s = (inter / (ta.size + tb.size - inter)) * 80;
  if (a.includes(b) || b.includes(a)) s += 15 * (Math.min(a.length, b.length) / Math.max(a.length, b.length));
  return s;
}

const EXTRAS = /(soundtrack|\bost\b|\bdlc\b|\bdemo\b|bundle|season pass|artbook|art book|expansion|upgrade|\bpack\b|playtest|dedicated server)/i;

// Steam installs record their app id in steamapps/appmanifest_<id>.acf -> exact match, no guessing
function steamAppIdFor(dir) {
  try {
    if (typeof dir !== 'string' || !dir) return null;
    const parts = path.resolve(dir).split(path.sep);
    const i = parts.map((p) => p.toLowerCase()).lastIndexOf('common');
    if (i < 1 || parts[i - 1].toLowerCase() !== 'steamapps' || !parts[i + 1]) return null;
    const steamapps = parts.slice(0, i).join(path.sep) || path.sep;
    const installdir = parts[i + 1].toLowerCase();
    for (const f of fs.readdirSync(steamapps)) {
      const m = f.match(/^appmanifest_(\d+)\.acf$/i);
      if (!m) continue;
      const txt = fs.readFileSync(path.join(steamapps, f), 'utf8');
      const d = txt.match(/"installdir"\s+"([^"]+)"/i);
      if (d && d[1].toLowerCase() === installdir) return m[1];
    }
  } catch { /* fall through to name search */ }
  return null;
}

ipcMain.handle('covers:find', async (_e, req) => {
  const name = String((req && req.name) || '');
  if (!name) return { ok: false, reason: 'nomatch' };
  try { fs.mkdirSync(coversDir(), { recursive: true }); } catch { return { ok: false, reason: 'nomatch' }; }

  let appid = steamAppIdFor(req.dir);
  let title = name;
  let tiny = '';
  if (!appid) {
    const q = cleanGameName(name);
    if (q.length < 2) return { ok: false, reason: 'nomatch' };
    const r = await netGet(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(q)}&l=english&cc=US`);
    if (!r.ok) return { ok: false, reason: r.network ? 'network' : 'nomatch' };
    let items = [];
    try { items = JSON.parse(r.buf.toString('utf8')).items || []; } catch { return { ok: false, reason: 'nomatch' }; }
    let best = null;
    let bestScore = 0;
    for (const it of items) {
      if (!it || it.type !== 'app' || !it.id || !it.name) continue;
      let s = similarity(q, it.name);
      if (EXTRAS.test(it.name) && !EXTRAS.test(q)) s -= 30;
      if (s > bestScore) { bestScore = s; best = it; }
    }
    if (!best || bestScore < 60) return { ok: false, reason: 'nomatch' }; // a wrong cover is worse than none
    appid = String(best.id);
    title = best.name;
    tiny = best.tiny_image || '';
  }

  const file = path.join(coversDir(), `steam-${appid}.jpg`);
  if (!fs.existsSync(file)) {
    const urls = [
      `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/${appid}/header.jpg`,
      `https://cdn.cloudflare.steamstatic.com/steam/apps/${appid}/header.jpg`,
      `https://cdn.akamai.steamstatic.com/steam/apps/${appid}/header.jpg`
    ];
    if (/^https:\/\/[\w.-]*steamstatic\.com\//i.test(tiny)) urls.push(tiny);
    let got = null;
    let netFail = false;
    for (const u of urls) {
      const r = await netGet(u);
      if (r.ok && isImage(r.buf)) { got = r.buf; break; }
      if (r.network) netFail = true;
    }
    if (!got) return { ok: false, reason: netFail ? 'network' : 'nomatch' };
    try { fs.writeFileSync(file, got); } catch { return { ok: false, reason: 'nomatch' }; }
  }
  return { ok: true, url: pathToFileURL(file).href, title, appid };
});

ipcMain.handle('covers:pick', async (_e, id) => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Choose a cover image', properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'bmp', 'gif'] }]
  });
  if (r.canceled) return null;
  try {
    fs.mkdirSync(coversDir(), { recursive: true });
    const key = crypto.createHash('sha1').update(String(id)).digest('hex').slice(0, 12);
    const dest = path.join(coversDir(), `manual-${key}-${Date.now()}${path.extname(r.filePaths[0]).toLowerCase()}`);
    fs.copyFileSync(r.filePaths[0], dest);
    return { ok: true, url: pathToFileURL(dest).href };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// The program's own icon (works offline for every .exe)
ipcMain.handle('games:exeIcon', async (_e, exe) => {
  if (typeof exe !== 'string' || !/\.exe$/i.test(exe)) return null;
  try {
    const img = await app.getFileIcon(exe, { size: 'large' });
    return img && !img.isEmpty() ? img.toDataURL() : null;
  } catch { return null; }
});

// ---------- custom app icons ----------
// Packaged: an "icons" folder next to WebOS.exe.  Dev (npm start): the "icons" folder in the project.
const ICONS_DIR = app.isPackaged ? path.join(path.dirname(process.execPath), 'icons') : path.join(__dirname, 'icons');
const ICON_NAMES = {
  browser: 'browser', optimizer: 'optimizer', games: 'games', game: 'games',
  gamelauncher: 'games', launcher: 'games', settings: 'settings'
};
const ICON_README =
  'Drop pictures here to replace the WebOS app icons.\r\n\r\n' +
  'Name each picture after the app:\r\n' +
  '  browser.png      -> Browser\r\n' +
  '  optimizer.png    -> Optimizer\r\n' +
  '  games.png        -> Game Launcher\r\n' +
  '  settings.png     -> Settings\r\n\r\n' +
  'Works with .png .jpg .jpeg .webp .gif .svg .ico .bmp (square pictures look best).\r\n' +
  'Switch back to WebOS and the new icons appear automatically.\r\n' +
  'Delete a picture to get the default icon back.\r\n';

function ensureIconsDir() {
  try {
    fs.mkdirSync(ICONS_DIR, { recursive: true });
    const readme = path.join(ICONS_DIR, 'README.txt');
    if (!fs.existsSync(readme)) fs.writeFileSync(readme, ICON_README);
  } catch { /* read-only location: icons are optional */ }
}

ipcMain.handle('icons:list', async () => {
  ensureIconsDir();
  const icons = {};
  let files = [];
  try { files = await fs.promises.readdir(ICONS_DIR); } catch { /* none */ }
  for (const f of files.sort()) {
    const m = f.match(/^(.+)\.(png|jpe?g|webp|gif|svg|ico|bmp)$/i);
    if (!m) continue;
    const id = ICON_NAMES[m[1].toLowerCase().replace(/[\s_-]+/g, '')];
    if (!id || icons[id]) continue;
    const full = path.join(ICONS_DIR, f);
    try { icons[id] = pathToFileURL(full).href + '?v=' + Math.round((await fs.promises.stat(full)).mtimeMs); } catch { /* skip */ }
  }
  return { dir: ICONS_DIR, icons };
});

ipcMain.handle('icons:open', async () => {
  ensureIconsDir();
  const err = await shell.openPath(ICONS_DIR);
  return err ? { ok: false, error: err } : { ok: true };
});

ipcMain.handle('window:fullscreen', () => { if (win) win.setFullScreen(!win.isFullScreen()); });
ipcMain.handle('app:quit', () => app.quit());
