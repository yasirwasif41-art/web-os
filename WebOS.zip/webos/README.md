# WebOS

A mini desktop operating system that runs as a Windows app. It has a desktop, taskbar, start menu and draggable/resizable windows, plus four apps:

| App | What it does |
| --- | --- |
| 🌐 **Browser** | Tabs, address bar that also searches (Google, DuckDuckGo, Bing, Brave, YouTube), ☆ to save sites, saved-sites bar and start page |
| ⚡ **Optimizer** | Live CPU/RAM, junk cleaner (temp files, crash dumps), "Game boost" (High performance power plan + DNS flush), list of running apps with an **End** button |
| 🎮 **Game Launcher** | Scans Steam / Epic / GOG / `C:\Games` etc. for `.exe` files, shows them as cards, one-click **Play**, favorites, recent, hide, add your own folder or `.exe` |
| ⚙️ **Settings** | 12 built-in wallpapers or your own image, accent colour, 12/24h clock, default search engine, system info |

## Run it

1. Install **Node.js** (LTS) from https://nodejs.org
2. Double-click **`run.bat`** (first launch installs Electron, which takes a minute)

Or in a terminal: `npm install` then `npm start`.

## Make a standalone WebOS.exe

Double-click **`build.bat`**. When it finishes, open `dist\WebOS-win32-x64\` and run **WebOS.exe**. You can zip that folder to share it or move it anywhere.

## Game cover art

The Game Launcher looks up cover art for your games online and shows it on each card:

- Steam games are matched exactly using the install's own app id; everything else is matched by name against the public Steam store search. If nothing matches closely enough, no cover is used (a wrong cover is worse than none) and the game shows its own program icon instead.
- It runs automatically after a scan (untick *Find cover art online automatically* to turn that off) or on demand with **🖼 Find covers**. Games that had no match aren't retried for a week unless you press the button.
- Right-click a game for **Find cover art online**, **Choose cover image…** (use your own picture) or **Remove cover**.
- Images are saved in a `covers` folder inside WebOS's data folder (`%APPDATA%\WebOS`), so they load instantly and work offline afterwards.
- Privacy: the only thing sent is the game's name (to Steam's store search) and the image downloads from Steam's servers.

## Custom app icons

Open the **`icons`** folder (next to `run.bat`, or next to `WebOS.exe` after building; also reachable from Settings → Personalization → *Open icons folder*) and drop in pictures named after the app:

`browser.png` · `optimizer.png` · `games.png` · `settings.png`

PNG, JPG, WEBP, GIF, SVG, ICO and BMP all work. Switch back to WebOS and the icons update on their own. Delete a picture to get the default icon back.

## Windows-style desktop

Centered taskbar with pinned apps and running indicators (click to open, minimize or cycle windows, right-click to close), Start menu with search (type something that isn't an app to search the web), "show desktop" strip at the far right, and window snapping: drag a window to the left/right edge to fill half the screen, or to the top edge to maximize.

## Tips

- In the Browser: **Ctrl+T** new tab, **Ctrl+W** close tab, **Ctrl+L** address bar, **F5 / Ctrl+R** reload, **Alt+←/→** back/forward. Right-click inside a page for open-link-in-new-tab, copy and search-selection.
- **F11** toggles fullscreen. Right-click the desktop for shortcuts.
- Some games need admin rights — Windows will show its normal prompt when you press Play.
- The Optimizer's junk cleaner only touches temp folders and skips files that are in use. System-critical processes can't be ended from the list.
- Right-click a game card (or press ⋯) to pick a different `.exe` from the same folder, open its folder, or hide it.

## Project layout

```
main.js        Electron main process (scanning, launching, cleaning, system stats)
preload.js     Safe bridge between the UI and main.js
index.html     Desktop shell
styles.css     All styling
js/os.js       Window manager, taskbar, start menu
js/browser.js  js/optimizer.js  js/games.js  js/settings.js   the apps
```
